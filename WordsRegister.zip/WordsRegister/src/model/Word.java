package model;

public class Word {
    private String word;
    private String mean;
    private String link;
    
    public Word(){}
    
    public Word(String word, String meaning){
        this.word = word;
        this.mean = meaning;
    }
    
    public String getWord() {
        return word;
    }
    public void setWord(String word) {
        this.word = word;
    }
    public String getMean() {
        return mean;
    }
    public void setMean(String mean) {
        this.mean = mean;
    }
    public String getLink() {
        return link;
    }
    public void setLink(String link) {
        this.link = link;
    }
    
    
}
