package register;

import java.util.List;
import java.util.ArrayList;
/*
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import model.Word;
/*
//class for executing h2.sh automatically
public class DbOpener {
    public static void main(String args[]){
        System.setProperty("webdriver.chrome.driver", "Driver/chromedriver");
        //create a driver instance 
        WebDriver driver = new ChromeDriver();
      //  WebDriver driver = new RemoteWebDriver();
        //startup chrome and open http://www.asial.co.jp
        driver.get("http://localhost");
        //get element text login and click it 
        //WebElement e1 = driver.findElement(By.id("a.text.login"));
        //e1.click();
        
        driver.findElement(By.cssSelector("a.text.login")).click();
        //pass login info(Email, Pass)
        try{
            driver.findElement(By.id("login.active.user")).sendKeys("kishiwda_kn@yahoo.co.jp");
            ExcutePrinter.exePrint("id is inserted");
            driver.findElement(By.id("password.active.password")).sendKeys("sanasana");    
            ExcutePrinter.exePrint("password is inserted");
            driver.findElement(By.id("div.button.mini.btn-login")).click();
        }catch(Exception e){
            ExcutePrinter.exePrint(e.getMessage());
        }finally{
          driver.close();
          driver.quit();
        }
    }
    /*
    public void testAuthenticationFailureWhenProvidingBadCredentials(){
        driver.findElement(By.id("username")).sendKeys("fakeuser");
        driver.findElement(By.id("password")).sendKeys("fakepassword");     
        driver.findElement(By.id("login")).click();

        assertTrue(driver.getCurrentUrl().endsWith("failed"));
    }
    */
    /**
     * テキストフィールドの入力処理
     *
     * @param locator
     * @param text
     */
   /*
    public void type(By locator, String text) {
        WebElement element = driver.findElement(locator);
        element.sendKeys(text);
    }
   *///}
