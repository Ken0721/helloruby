package register;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.Word;

/**
 * Servlet implementation class ControllerServlet
 */
@WebServlet("/ControllerServlet")
public class ControllerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ControllerServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 * 
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	    request.setCharacterEncoding("UTF-8");
	    WordDao wDao = new WordDao();
	    wDao.refresh();
	    request.getRequestDispatcher("/WEB-INF/jsp/top.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	    request.setCharacterEncoding("UTF-8");
	    String newWord = request.getParameter("word");
	    String fake = "";
	    // Create Word, DbOpener, List instances
	    Word word = new Word();
	    //DbOpener dbOp = new DbOpener();
	    WordDao wDao = new WordDao();
	    
	    word.setWord(newWord);
	    word.setMean(fake);
	    String str = wDao.register(word.getWord(), word.getMean());
	    String lastWord = wDao.getLastWord();
	    request.setAttribute("lastword", lastWord);
	    request.setAttribute("mssg", str);
	    request.getRequestDispatcher("/WEB-INF/jsp/top.jsp").forward(request, response);
	}
}
