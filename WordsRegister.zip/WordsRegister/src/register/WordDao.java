package register;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import model.Word;

/**
 * @param newWord, newMeaning
 * @author kennosuke
 *
 */
public class WordDao {
    String err=null;
    public String register(String newWord, String newMeaning){
        Connection conn = null;
        if(!wordDbCheck(newWord)){
            err="The word " + newWord + " already exits.";
            return err;
        }
            
        try {
            // JDBCドライバを読み込み
            Class.forName("org.h2.Driver");
            // データベースへ接続
            conn = DriverManager.getConnection( "jdbc:h2:~/test", "ken", "ken");
            
          // SELECT文を準備, table wordslist have to be created in advance
//          String sql1 = "CREATE TABLE WORDSLIST(WORD VARCHAR(20) PRIMARY KEY, MEANING VARCHAR(255) NOT NULL);";
          String sql2 = "INSERT INTO WORDSLIST(WORD, MEANING, DATE, INDEX) VALUES(?,?,?,?)";
 //         PreparedStatement pStmt1 = conn.prepareStatement(sql1);
          PreparedStatement pStmt2 = conn.prepareStatement(sql2);
          
          pStmt2.setString(1, newWord);
          pStmt2.setString(2, newMeaning);
          pStmt2.setDate(3, getCurrentDatetime());
          //System.out.println("lie 41" + getMaxIndex()+1 );
          pStmt2.setInt(4, getMaxIndex()+1);
          //Execute the sql sentence
          pStmt2.executeUpdate();
          return null;
        } catch (SQLException e) {
          e.printStackTrace();
      //    return null;
        } catch (ClassNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } finally {
          // データベース切断
          if (conn != null) {
            try {
              conn.close();
            } catch (SQLException e) {
              e.printStackTrace();
            }
          }
        }
        return null;
    }
    
    /**
     * @param newWord
     * @return
     * This method check if the word already exit on the database
     */
    public boolean wordDbCheck(String newWord){
        Connection conn = null;
        int maxIndex=0;
        try {
            // JDBCドライバを読み込み
            Class.forName("org.h2.Driver");
            // データベースへ接続
            conn = DriverManager.getConnection( "jdbc:h2:~/test", "ken", "ken");
            String sql = "SELECT ? FROM WORDSLIST";
            PreparedStatement pStmt = conn.prepareStatement(sql);
            pStmt.setString(1, newWord);
            ResultSet rs = pStmt.executeQuery();
            while(rs.next()){
                //System.out.println("line 82");
                return true;
            }
            return false;
        } catch (SQLException e) {
            e.printStackTrace();
            //    return null;
              } catch (ClassNotFoundException e) {
                  // TODO Auto-generated catch block
                  e.printStackTrace();
              } finally {
                  // データベース切断
                  if (conn != null) {
                      try {
                          conn.close();
                      } catch (SQLException e) {
                        e.printStackTrace();
                      }
                  }
              }
        return false;
    }
    //get highest index(get the latest added word)

    public int getMaxIndex(){
        Connection conn = null;
        int maxIndex=0;
        try {
            // include JDBC driver
            Class.forName("org.h2.Driver");
            // connect to database
            conn = DriverManager.getConnection( "jdbc:h2:~/test", "ken", "ken");       
            // SELECT文を準備, table wordslist have to be created in advance
    //      String sql1 = "CREATE TABLE WORDSLIST(WORD VARCHAR(20) PRIMARY KEY, MEANING VARCHAR(255) NOT NULL);";
            String sql = "SELECT MAX(INDEX) FROM WORDSLIST";
            PreparedStatement pStmt = conn.prepareStatement(sql);
            ResultSet rs = null;
            rs = pStmt.executeQuery();
            while(rs.next()){
                maxIndex = rs.getInt("MAX(INDEX)");
            }
            return maxIndex;
        } catch (SQLException e) {
          e.printStackTrace();
      //    return null;
        } catch (ClassNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } finally {
            // データベース切断
            if (conn != null) {
                try {
                    conn.close();
                } catch (SQLException e) {
                  e.printStackTrace();
            //    return null;
                }
            }
        }
        return maxIndex;
    }

    public String getLastWord() {
        String str=null;
        Connection conn = null;
        try{
            // JDBCドライバを読み込み
            Class.forName("org.h2.Driver");
            // データベースへ接続
            conn = DriverManager.getConnection( "jdbc:h2:~/test", "ken", "ken");
            String sql = "SELECT * from WORDSLIST WHERE INDEX = ?";
            PreparedStatement pStmt = conn.prepareStatement(sql);
            pStmt.setInt(1, getMaxIndex());
            ResultSet rs = pStmt.executeQuery();
            if(rs.next()){
               str = rs.getString("WORD");
            }
            return str;
        }catch(SQLException e){
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } finally {
            // データベース切断
            if (conn != null) {
              try {
                conn.close();
              } catch (SQLException e) {
                e.printStackTrace();
                return str;
              }
            }
        }
        return str;
    }

    public java.sql.Date getCurrentDatetime() {
        java.util.Date today = new java.util.Date();
        return new java.sql.Date(today.getTime());
    }
    
    public List<Word> getWordsList() {
        
        Connection conn = null;
        List<Word> wordList = new ArrayList<Word>();
        try{
         // include JDBC driver
            Class.forName("org.h2.Driver");
            //Conect to the database
            conn = DriverManager.getConnection(
                    "jdbc:h2:~/test", "ken", "ken");
            String sql = "SELECT * FROM WORDSLIST";
            PreparedStatement pStmt = conn.prepareStatement(sql);
            //pStmt3.setString(1, newWord.);
            ResultSet rs = pStmt.executeQuery();
            
            while(rs.next()){
                String newWord = rs.getString("WORD");
                String mean = rs.getString("MEANING");
                Word word  = new Word(newWord, mean);
                wordList.add(word);
                //System.out.println("line207");
            }
            return wordList;
        }catch(SQLException e){
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } finally {
        // データベース切断
        if (conn != null) {
          try {
            conn.close();
          } catch (SQLException e) {
            e.printStackTrace();
            return null;
          }
        }
      }
      return null;
    }

    public void refresh(){
        Connection conn = null;
        try{
            // include JDBC driver
            Class.forName("org.h2.Driver");
            // get connection to the database
            conn = DriverManager.getConnection( "jdbc:h2:~/test", "ken", "ken");
            //make index in order
            String getAllSql="SELECT * FROM WORDSLIST ORDER BY INDEX ASC";
            String changeSql="Update WORDSLIST SET INDEX = ?";
            PreparedStatement pstm1 = conn.prepareStatement(getAllSql);
            PreparedStatement pstm2 = conn.prepareStatement(changeSql);
            ResultSet rs1;
            rs1 = pstm1.executeQuery();
            int i = 1;
            String str;
            while(rs1.next()){
                System.out.println("line"+i);
                pstm2.setInt(1, i);
                //str=rs1.getString("WORD");
                //System.out.println("str is "+str);
                //index = rs1.getInt("INDEX");
                //pstm2.setInt(2, index);
                //execute SQL
                System.out.println(changeSql);
                pstm2.executeUpdate();
                i=i+1;
            }
        }catch(SQLException e){
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } finally {
            // データベース切断
            if (conn != null) {
                  try {
                    conn.close();
                  } catch (SQLException e) {
                    e.printStackTrace();
                  }
            }
        
        }
    }
}


// 結果表に格納されたレコードの内容を
// Employeeインスタンスに設定し、ArrayListインスタンスに追加
/*          while (rs.next()) {
  String word = rs.getString("ID");
  String name = rs.getString("NAME");
  int age = rs.getInt("AGE");
  Employee employee = new Employee(id, name, age);
  empList.add(employee);
}
*/